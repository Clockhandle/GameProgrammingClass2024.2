﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnitAwaitDeploymentState : UnitStates
{
    public override void StartState(Unit unit)
    {
        base.StartState(unit);
    }

    public override void UpdateState(Unit unit) 
    {
        base.UpdateState(unit); 
    }

    public override void ExitState(Unit unit)
    {
        base.ExitState(unit);
    }
}