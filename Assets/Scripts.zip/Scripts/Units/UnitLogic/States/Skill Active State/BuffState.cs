using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuffState : UnitState
{
    public BuffState(Unit unit, UnitStateMachine sm) : base(unit, sm) 
    {
            
    }
}
