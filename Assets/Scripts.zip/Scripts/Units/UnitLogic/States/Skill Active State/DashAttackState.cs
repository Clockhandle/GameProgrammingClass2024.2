using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DashAttackState : UnitState
{
    public DashAttackState(Unit unit, UnitStateMachine stateMachine) : base(unit, stateMachine)
    {
    }
}
